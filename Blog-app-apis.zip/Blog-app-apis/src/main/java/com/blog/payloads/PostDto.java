package com.blog.payloads;

import com.blog.entities.Category;
import com.blog.entities.User;

import jakarta.persistence.criteria.CriteriaBuilder.In;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PostDto {

	private Integer postId;
	
	private String title;

	private String content;

//	private String imageName="default.png";

	private String imageName;

	private String addedDate;

	private Category category;

	private User user;

}
